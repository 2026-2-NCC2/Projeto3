export default function Footer() {
  return (
    <footer className="footer">
      <p>&copy; 2026 TrocaTicket. Projeto Interdisciplinar FECAP.</p>
    </footer>
  )
}